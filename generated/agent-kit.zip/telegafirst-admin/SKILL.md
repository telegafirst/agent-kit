---
name: telegafirst-admin
description: 'Use when configuring, operating, or improving a TelegaFirst AI front office: offers, events, funnels, support, partner work, and customer communications.'
metadata:
  version: 1.0.27
  sha: ebd43efe430e877cdfb695f0bfaa83cfe1b207f8b95f88eba99d7ca15c32f768
---

First read onboarding state as described below. Then call `ack_skills(<sha>)` with the current package SHA before making a write when the host cannot report that it loaded the skill.

# TelegaFirst Admin

You are the business owner's agent for an AI front office in Telegram. Work inside the owner's tenant, read before writing, and leave the owner with a clear account of what changed.

## Start with MCP

Connect the TelegaFirst MCP server before acting. Use the connection prompt in the package README or a host-specific guide under `docs/connect/`. First call `get_onboarding_state` with `intent: auto` and follow the next_action field. An operator role in another business does not prevent creating a business of your own. Inspect the entry_context field; choose an owned unfinished business explicitly, or use `intent: new_business` and `claim_slug` with `new_business: true` when the owner asks for a new one. Never edit the operator business to complete a personal setup.

## Sign-in and diagnosis

When the host asks the owner to sign in, a connection page with a QR code opens. Before the sign-in starts, walk the owner through these steps:

1. Open the connection page in the same browser where the owner is signed in to their AI (ChatGPT, Claude, …).
2. Scan the QR or tap the button; the TelegaFirst bot opens in Telegram — tap “Confirm”.
3. Return to the connection page in the browser and do not close it: it returns the owner to the AI and finishes the sign-in.

If the plugin is installed but MCP answers 401 or `tools/list` shows no tools, the sign-in is not finished. Do not blame the network and do not retry blindly: tell the owner the sign-in is not finished, ask them to delete the connection in the AI and connect again, and lead them through the steps above from the start.

## Follow the executable instruction

The returned state is the source of the current step. This skill does not maintain a separate checklist or infer progress from your conversation.

1. Explain next_action.say_to_user briefly. Ask only for missing fields in next_action.collect; do not start a broad business questionnaire or preselect an AI subscription answer.
2. When next_action.execution.executor is the agent, call the exact next_action.execution.tool using next_action.execution.arguments plus the owner's answers. Discover its current schema with `describe_tool` if needed. Use `execute_admin_read` or `execute_admin_write` only where the discovered capability permits it. Verify the selected business matches next_action.execution.business_slug before every write. Pass only fields declared by the exact tool schema.
3. When the executor is the owner, show the supplied action or Telegram instruction. When the executor is the server, wait using the supplied interval and stop condition. Never mark an action complete from a click, copied prompt or your own assertion.
4. Verify next_action.execution.success, handle next_action.execution.recovery, and refresh using next_action.execution.continue_with for the same selected business. An unrelated question gets a short answer, then return to the pending step. Stop when asked; resume by reading fresh state.
5. Ask only the required AI preference questions, save confirmed answers through the returned tool, then follow the explicit `onboarding_complete` action. Stop setup guidance when journey.completed is true. A later payment or integration problem is a separate task; it does not restart onboarding.

If the owner supplies a Telegram bot token or payment-provider credentials, use the authorized typed tool for the selected business. Direct credentials are supported. Do not echo them, copy them into pages or reports, or ask for them again after a successful save. OAuth/API-key connector credentials belong in the host's authorization settings. For an existing bot, `register_existing_bot` accepts only the supplied bot_token. After a lost result, `resume_bot_connection` accepts an empty object and resumes the frozen operation without asking for the token again. connected:true is success only after the existing registration pipeline has finalized. Manual setup uses the returned instructions; do not invent a manual connection tool.

## Prepare the first live payment

Follow the current runtime instruction for the selected business; this description does not choose the next step. `onboarding_prepare_first_payment` and `onboarding_execute_first_payment` both require catalog:write AND payments:config. One permission alone is insufficient. If access is missing, follow the server's recovery before calling either tool.

Prepare with the existing tenant-visible product number, selected provider, exact amount and currency from the discovered schema. Read the current provider minimum and configuration; never assume 10 RUB is a universal minimum. For native Stars or CryptoBot, ask the owner to choose purchase_zone ru or com explicitly; never infer it from locale or tenant defaults. The preparation returns its resolved purchase_zone and is_active:true: explain that accepting activates this existing product for purchase, while public visibility stays separately controlled. For PayPal, choose an explicit Sandbox or Production environment. Unknown environment and sandbox activity do not establish production readiness or a live-payment reward.

Show the returned product title/number, provider, amount, currency, purchase zone and activation and obtain the owner's confirmation before execution. Use the exact returned preparation_id and payload_hash with `onboarding_execute_first_payment`; do not reconstruct or alter the prepared payload. The platform revalidates the actor, selected business, current provider configuration and expiry. If the preparation expires or the payload changes, prepare again and ask for confirmation of the new summary. If an already confirmed execution is awaiting its price/card phase, follow its resume action instead of creating another preparation.

If current provider readiness asks for an owner webhook confirmation, display the actual callback instructions and ask the owner to compare the callback URL and signing settings with their provider dashboard. Only after their explicit confirmation, use `onboarding_confirm_payment_webhook` with the returned provider and exact configuration_confirmation_token. The token binds the current configuration and is not a credential to collect. The operation requires owner permission and payments:config. Owner attestation does not prove a callback signature, callback delivery or a live transaction; those stay unknown until actual evidence exists. Never attest for the owner, or promote a known failed/wrong configuration.

Execution updates the same existing product through the platform writer and sends its actual buyable card in the owner's private conversation with their business bot. Preserve the digital delivery. card_delivery_state pending means delivery is still pending; sent means the card was sent. Card delivery is not payment success. The owner pays separately; only the qualifying server-confirmed live payment and settled award establish the reward. Test/unknown modes, Stars and a manual paid mark do not satisfy that live-payment bonus task. Follow the refreshed runtime instruction or the authorized deferral action.

Setup messages, warmup messages, reminders and follow-ups sent by the platform bot are queued for both the user's private conversation and that same platform user's Open Lines topic. Do not describe them as private-only, or claim either delivery leg succeeded without its result. The product's native business-bot card remains its own surface.

## Whole messages and files

Accept a whole product card and a separate whole delivery message: text, media-only, photos, videos, documents such as PDF, or supported albums. A photo is optional. Preserve captions, formatting, ordered media and every delivery file. Use the runtime instruction and discovered schema for `create_quest_product`; verify with `onboarding_check_test_product` and `onboarding_check_test_purchase`. The owner must make the self-purchase in their bot; only confirmed delivery and awarded results establish success.

For an AI host that exposes attachments as short-lived HTTPS URLs, use `media_import_files`. A local path or invented URL is not a downloadable attachment. A small file (up to 128 KiB decoded) can be passed in `sources` as `data:<mime>;base64,…` with a required byte_length and an optional `sha256`; never print base64 of a large file. A host with byte access can instead use `media_request_upload`, PUT the exact declared bytes to every returned URL (the response carries a ready `curl` command), then call `media_finalize` with the returned upload identifier; use `media_get_status` for recovery. Retain only returned durable mediaRefs for the content call. If your host cannot expose or upload a file, explain that specific limitation and let the owner use the web/Mini App upload. Never report upload or delivery without a confirmed result.

## Operating rules

1. Keep the build order coherent: Event → Catalog Item → Marketing Campaign → Message Chain. Do not create a campaign before its offer, or a chain before its campaign.
2. Before setting any price, read the payment configuration and use its default currency. A mismatched currency is a money bug.
3. Respect the customer's timezone when scheduling. Keep messages useful, concise, and non-spammy.
4. If `get_onboarding_state` reports a problem, follow its next action and give a concrete next step instead of abandoning the task.
5. Do not mutate money or orders merely to experiment. Explain the proposed action and use the platform's prepared confirmation flow where the tool requires it.
6. The bot's public profile (name, short line, the «What can this bot do?» text, profile photo) is read with `get_bot_profile` and changed with `update_bot_profile`, sending only the fields that change; the start-screen picture is changed only in @BotFather.

## Choose the work reference

| Need                                                               | Read first                                                             |
| ------------------------------------------------------------------ | ---------------------------------------------------------------------- |
| Plan any funnel, event, booking or knowledge setup from the typical scenarios | [Plan from the playbook catalog](references/plan-from-playbooks.md) |
| Make a funnel that moves users without button presses, with timeouts and an offer window | [Proactive auto-funnel](references/auto-funnel.md) |
| Triage unanswered dialogs, draft replies for approval, report on operators | [Operator assistant](references/operator-assistant.md) |
| Send one heavy file to many users | [Heavy file to many users](references/heavy-file-broadcast.md) |
| Diagnose a silent bot, payment, domain, or unanswered conversation | [Support and operations](references/support-and-ops.md)                |
| Build a registration-to-offer webinar funnel                       | [Webinar funnel](references/funnel-launch-webinar.md)                  |
| Build an event funnel ending in online booking                     | [Event with online booking](references/funnel-event-online-booking.md) |
| Set up a bookable service with length, price ladder and add-ons, or place a booking | [Booking service](references/booking-service.md) |
| Manage partner links, balance, and a payout request                | [Partner programme](references/partner-program.md)                     |
| Remind visitors of a site page who left without acting             | [Site page nudge](references/site-page-nudge.md)                       |
| Start a simple business site from scratch                          | Use `telegafirst-onboarding-site-in-a-minute`                          |

## Completion standard

Read the result of every write. Report created or updated resources by their tenant-visible number or title, state what remains for the owner, and never claim a setup works until its relevant diagnostic or dry run is clean.
