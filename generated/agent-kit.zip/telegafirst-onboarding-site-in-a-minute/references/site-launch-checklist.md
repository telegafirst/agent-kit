# Site launch checklist

- Confirm the owner chose the right jurisdiction zone for the domain.
- Keep the complete site bundle available before requesting uploads.
- Check the plan's published HTML page limit separately from the bundle byte limit and the technical cap of 10 000 files on every plan. Hidden pages, assets, private HTML fragments and automatic platform pages do not consume the page limit; excess pages stay `published:false`. Each host has independent limits; publishing does not copy the site to `.com`.
- Verify the public call to action leads to the intended TelegaFirst bot.
- Declare any form before publishing its page.
- Every page footer links `/terms`, `/privacy` and `/legal`; the bundle has no legal pages of its own.
- Read the manifest after publishing and report the active host to the owner.
- Give the owner the links of every published page from **page_urls** (or `site_list_pages`), each with what it is for; an empty **page_urls** is not done until its recovery is followed.
- A closed section is closed by a password on the platform and a rule that names it, never by a script in the page; the owner has the password to hand to the audience.
